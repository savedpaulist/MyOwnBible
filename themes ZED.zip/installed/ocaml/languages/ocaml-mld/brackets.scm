("{" @open
  "}" @close)

("[" @open
  "]" @close)
